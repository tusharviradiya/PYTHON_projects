from django.apps import AppConfig


class EduAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "edu_app"
